using RestService.Model.Database;

namespace WebServerWPF.RestDTOs
{
    public class RequestPostUser
    {
        public User User { get; set; }
    }
}