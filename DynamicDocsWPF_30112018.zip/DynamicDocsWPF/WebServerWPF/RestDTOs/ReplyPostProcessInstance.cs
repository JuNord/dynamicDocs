using RestService;

namespace WebServerWPF.RestDTOs
{
    public class ReplyPostProcessInstance
    {
        public UploadResult UploadResult { get; set; }
    }
}