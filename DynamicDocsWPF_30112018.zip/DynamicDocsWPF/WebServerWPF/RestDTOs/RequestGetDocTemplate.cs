namespace WebServerWPF.RestDots
{
    public class RequestGetDocTemplate
    {
        public string Id { get; set; }
    }
}