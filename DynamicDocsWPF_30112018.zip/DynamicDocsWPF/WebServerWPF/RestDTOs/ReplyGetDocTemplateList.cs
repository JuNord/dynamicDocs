using System.Collections.Generic;
using RestService.Model.Database;

namespace WebServerWPF.RestDTOs
{
    public class ReplyGetDocTemplateList
    {
        public List<DocTemplate> DocTemplates { get; set; }
    }
}