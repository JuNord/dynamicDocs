namespace WebServerWPF.RestDTOs
{
    public class RequestGetPermissionLevel
    {
        public string Username { get; set; }
    }
}