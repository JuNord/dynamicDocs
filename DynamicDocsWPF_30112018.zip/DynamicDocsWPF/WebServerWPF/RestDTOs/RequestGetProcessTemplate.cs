namespace WebServerWPF.RestDots
{
    public class RequestGetProcessTemplate
    {
        public string Id { get; set; }
    }
}