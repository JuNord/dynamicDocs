using RestService.Model.Database;

namespace WebServerWPF.RestDTOs
{
    public class RequestPostProcessInstance
    {
        public RunningProcess RunningProcess { get; set; }
    }
}