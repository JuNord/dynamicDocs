namespace WebServerWPF.RestDTOs
{
    public class RequestGetEntryList
    {
        public int InstanceId { get; set; }
    }
}