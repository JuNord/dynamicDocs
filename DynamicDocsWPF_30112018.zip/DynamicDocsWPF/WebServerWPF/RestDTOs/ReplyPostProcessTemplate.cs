using RestService;

namespace WebServerWPF.RestDTOs
{
    public class ReplyPostProcessTemplate
    {
        public UploadResult UploadResult { get; set; }
    }
}