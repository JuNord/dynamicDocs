using System.Collections.Generic;
using RestService.Model.Database;

namespace WebServerWPF.RestDTOs
{
    public class ReplyGetProcessTemplateList
    {
        public List<ProcessTemplate> ProcessTemplates { get; set; }
    }
}