using DynamicDocsWPF.Model;

namespace WebServerWPF.RestDTOs
{
    public class ReplyGetAuthenticationResult
    {
        public AuthorizationResult AuthorizationResult { get; set; }
    }
}