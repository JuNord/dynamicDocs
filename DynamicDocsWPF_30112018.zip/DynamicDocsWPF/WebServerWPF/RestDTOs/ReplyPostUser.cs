using RestService;

namespace WebServerWPF.RestDTOs
{
    public class ReplyPostUser
    {
        public UploadResult UploadResult { get; set; }
    }
}