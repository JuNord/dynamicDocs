namespace WebServerWPF.RestDots
{
    public class RequestPostDocTemplate
    {
        public string Id { get; set; }
        public string Content { get; set; }
        public bool ForceOverWrite { get; set; }
    }
}