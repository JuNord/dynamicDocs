using RestService;

namespace WebServerWPF.RestDTOs
{
    public class ReplyPostEntry
    {
        public UploadResult UploadResult { get; set; }
    }
}