using RestService.Model.Database;

namespace WebServerWPF.RestDTOs
{
    public class ReplyGetProcessInstance
    {
        public RunningProcess ProcessInstance { get; set; }
    }
}