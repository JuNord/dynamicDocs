namespace WebServerWPF.RestDTOs
{
    public class ReplyGetPermissionLevel
    {
        public int PermissionLevel { get; set; }
    }
}