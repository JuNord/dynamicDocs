namespace WebServerWPF.RestDTOs
{
    public class ReplyGetDocTemplate
    {
        public string Id { get; set; }
        public string Content { get; set; }
    }
}