using RestService;

namespace WebServerWPF.RestDTOs
{
    public class ReplyPostDocTemplate
    {
        public UploadResult UploadResult { get; set; }
    }
}