namespace WebServerWPF.RestDTOs
{
    public class RequestGetProcessInstance
    {
        public int Id { get; set; }
    }
}