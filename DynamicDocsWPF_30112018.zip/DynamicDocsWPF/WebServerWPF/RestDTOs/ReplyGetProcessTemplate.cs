namespace WebServerWPF.RestDTOs
{
    public class ReplyGetProcessTemplate
    {
        public string Id { get; set; }
        public string Description { get; set; }
        public string Text { get; set; }
    }
}