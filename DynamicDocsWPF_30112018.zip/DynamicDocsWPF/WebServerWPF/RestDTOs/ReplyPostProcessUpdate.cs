using RestService;

namespace WebServerWPF.RestDTOs
{
    public class ReplyPostProcessUpdate
    {
        public UploadResult UploadResult { get; set; }
    }
}