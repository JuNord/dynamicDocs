using RestService.Model.Database;

namespace WebServerWPF.RestDTOs
{
    public class RequestPostEntry
    {
        public Entry Entry { get; set; }
    }
}