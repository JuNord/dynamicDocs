﻿namespace XmlProcessor
{
    internal class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}