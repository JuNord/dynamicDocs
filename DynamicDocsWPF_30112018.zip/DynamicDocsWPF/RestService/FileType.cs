namespace RestService
{
    public enum FileType
    {
        ProcessTemplate,
        DocTemplate
    }
}