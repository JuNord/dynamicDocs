namespace RestService
{
    public class FileRequest
    {
        public string Id { get; set; }
        public FileType FileType { get; set; }
    }
}