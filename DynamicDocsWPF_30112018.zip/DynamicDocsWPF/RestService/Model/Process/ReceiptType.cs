namespace RestService.Model.Process
{
    public enum ReceiptType
    {
        WORD
    }
}