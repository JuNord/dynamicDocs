namespace RestService.Model.Process
{
    public interface INotificationElement
    {
        void Send();
    }
}