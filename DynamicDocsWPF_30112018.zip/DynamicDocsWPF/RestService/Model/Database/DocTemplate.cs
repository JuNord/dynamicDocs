namespace RestService.Model.Database
{
    public class DocTemplate
    {
        public string Id { get; set; }
        public string FilePath { get; set; }
    }
}