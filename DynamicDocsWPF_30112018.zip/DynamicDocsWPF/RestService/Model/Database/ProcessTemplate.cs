namespace RestService.Model.Database
{
    public class ProcessTemplate
    {
        public string Id { get; set; }
        public string FilePath { get; set; }
        public string Description { get; set; }

        public override string ToString()
        {
            return Description;
        }
    }
}