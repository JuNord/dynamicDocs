namespace RestService.Model.Database
{
    public class ArchivePermission
    {
        public int ArchivedProcess_ID { get; set; }
        public string AuthorizedUser_ID { get; set; }
    }
}