namespace RestService.Model.Database
{
    public class Roles
    {
        public string Id { get; set; }
        public string User_ID { get; set; }
    }
}