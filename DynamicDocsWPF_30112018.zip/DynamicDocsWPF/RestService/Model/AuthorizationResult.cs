namespace DynamicDocsWPF.Model
{
    public enum AuthorizationResult
    {
        AUTHORIZED,
        NO_PERMISSION,
        INVALID_LOGIN,
        PERMITTED,
        INVALID_FORMAT
    }
}